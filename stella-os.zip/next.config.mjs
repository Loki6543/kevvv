/** @type {import('next').NextConfig} */
const nextConfig = {
  // Netlify handles the output automatically
};
export default nextConfig;